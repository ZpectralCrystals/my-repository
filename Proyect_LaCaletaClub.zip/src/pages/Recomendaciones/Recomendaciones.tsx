import React from 'react';



const Recomendaciones: React.FC = () => {
  return (
    <></>
  );
};

export default Recomendaciones;
