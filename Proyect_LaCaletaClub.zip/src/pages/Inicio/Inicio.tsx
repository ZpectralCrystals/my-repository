import React from 'react';



const Inicio: React.FC = () => {
  return (
    <>hola1</>
  );
};

export default Inicio;
