import React from 'react';



const Contacto: React.FC = () => {
  return (
    <></>
  );
};

export default Contacto;
