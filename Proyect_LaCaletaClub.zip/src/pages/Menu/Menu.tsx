import React from 'react';



const Menu: React.FC = () => {
  return (
    <></>
  );
};

export default Menu;
