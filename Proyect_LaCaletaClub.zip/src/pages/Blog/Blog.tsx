import React from 'react';



const Blog: React.FC = () => {
  return (
    <>
    <h1>hola</h1></>
  );
};

export default Blog;
