import React from 'react';



const Paginas: React.FC = () => {
  return (
    <></>
  );
};

export default Paginas;
