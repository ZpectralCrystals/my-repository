import React from 'react';



const Carrito: React.FC = () => {
  return (
    <></>
  );
};

export default Carrito;
